-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 18, 2019 at 07:40 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orderfood`
--
CREATE DATABASE IF NOT EXISTS `orderfood` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `orderfood`;

-- --------------------------------------------------------

--
-- Table structure for table `of_admin`
--

CREATE TABLE `of_admin` (
  `id` int(11) NOT NULL,
  `account` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `cate` tinyint(4) NOT NULL COMMENT '1: Admin, 2: Statistic, 3: Food&Cate, 4: Manager, 5: User, 6: Admin2',
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `of_admin`
--

INSERT INTO `of_admin` (`id`, `account`, `password`, `name`, `cate`, `active`) VALUES
(3, 'admin', 'ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413', 'Quản Trị Viên (Admin)', 1, 1),
(4, 'thongke', 'ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413', 'Thống Kê Viên', 2, 1),
(5, 'catefood', 'ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413', 'Quản Lý Loại & Sản Phẩm', 3, 1),
(6, 'quanly', 'ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413', 'Quản Lý ', 4, 1),
(7, 'quanlyban', 'ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413', 'Quản Lý Bàn', 5, 1),
(8, 'admin2', 'ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413', 'Admin 2', 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `of_bill`
--

CREATE TABLE `of_bill` (
  `id` int(11) NOT NULL,
  `code_order` varchar(500) NOT NULL,
  `order_id` int(11) NOT NULL,
  `num_table` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `discount` float NOT NULL,
  `active` int(11) NOT NULL COMMENT '0: chưa, 1: xong'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `of_category`
--

CREATE TABLE `of_category` (
  `id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `vi_name` varchar(255) NOT NULL,
  `en_name` varchar(1000) NOT NULL,
  `order` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `of_category`
--

INSERT INTO `of_category` (`id`, `department_id`, `vi_name`, `en_name`, `order`, `active`) VALUES
(1, 1, 'Cơm', 'Rices', 1, 1),
(2, 2, 'Nước Ngọt', 'Drink', 1, 1),
(3, 3, 'Trái Cây', 'Others', 1, 1),
(4, 1, 'Mì', 'Noodles', 2, 1),
(5, 1, 'Cháo', 'Soup', 3, 1),
(6, 2, 'Rượu', 'Wine', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `of_department`
--

CREATE TABLE `of_department` (
  `id` int(11) NOT NULL,
  `vi_name` varchar(255) NOT NULL,
  `en_name` varchar(255) NOT NULL,
  `img_url` varchar(255) NOT NULL,
  `order` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL,
  `solve_department` int(11) NOT NULL COMMENT '1.bếp 2.bếp phá chế'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `of_department`
--

INSERT INTO `of_department` (`id`, `vi_name`, `en_name`, `img_url`, `order`, `active`, `solve_department`) VALUES
(1, 'Đồ Ăn', 'Foods', 'food-eating-potatoes-beer-8313.jpg', 1, 1, 1),
(2, 'Thức Uống', 'Drinks', 'bar-beverage-cocktail-109275.jpg', 2, 1, 4),
(3, 'Món Khác', 'Others', 'pexels-photo-132694.jpeg', 3, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `of_discount`
--

CREATE TABLE `of_discount` (
  `id` int(11) NOT NULL,
  `create_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `discount` float NOT NULL,
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `of_food`
--

CREATE TABLE `of_food` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `vi_name` varchar(255) NOT NULL,
  `en_name` varchar(250) NOT NULL,
  `price` double NOT NULL,
  `price_discount` double NOT NULL,
  `discount` int(11) NOT NULL,
  `vi_desc` text NOT NULL,
  `en_desc` text NOT NULL,
  `img_url` varchar(255) NOT NULL,
  `img_url2` varchar(255) NOT NULL,
  `img_url3` varchar(255) NOT NULL,
  `img_url4` varchar(255) NOT NULL,
  `order` int(11) NOT NULL,
  `solve` bigint(11) NOT NULL,
  `active` tinyint(4) NOT NULL COMMENT '2: hết, 1: còn, 0: ngừng kinh doanh'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `of_food`
--

INSERT INTO `of_food` (`id`, `category_id`, `vi_name`, `en_name`, `price`, `price_discount`, `discount`, `vi_desc`, `en_desc`, `img_url`, `img_url2`, `img_url3`, `img_url4`, `order`, `solve`, `active`) VALUES
(1, 1, 'Ốc Xào Rang Me', 'Fried Escargot With Tamarind Sauce', 120000, 0, 10, '<p>Ốc bưu kết hợp với trai me tạo n&ecirc;n m&oacute;n Ốc s&agrave;o rang me si&ecirc;u ngon v&agrave; hấp dẫn.</p>\r\n', '<p>This text is in English</p>\r\n', 'oxrm.jpg', '', '', '', 1, 5, 2),
(2, 1, 'Cơm Chiên Dương Châu', 'Fried Rice ', 30000, 0, 0, 'Cơm chiên màu vàng và có cà rốt nên được gọi là cơm chiên Dương Châu.', 'This text is in English', 'ccdc.jpg', '', '', '', 2, 6, 1),
(3, 1, 'Cơm Cá Lóc Canh Chua', 'Rice And Sour Fish Broth', 35000, 0, 0, 'Cơm gồm cá lóc và canh chua nên được gọi là \"Cá lóc canh chua\".', '', 'cclcc.jpg', '', '', '', 3, 12, 1),
(4, 1, 'Ốc Móng Tay Xào Rau Muống', 'Solenidae With Fried Blinweed', 55000, 49500, 10, '<p>Ốc sạch v&agrave; rau sạch tạo n&ecirc;n 1 m&oacute;n ăn sạch v&agrave; đảm bảo sẽ ngon miệng.</p>\r\n', '', 'omtxrm.jpg', '', '', '', 4, 29, 1),
(5, 1, 'Nấm Mèo Rang Ớt', 'Fired Jelly Ear With Chilly', 45000, 0, 0, 'Nấm mèo được pha trộn với ớt tạo nên 1 món ăn vừa ngon vừa cay. Phù hợp với lứa tuổi trung niên và người có thể ăn cay.', '', 'nmro.jpg', '', '', '', 5, 10, 1),
(6, 1, 'Cải Xanh Xào Ớt Chuông', 'Fried Chinese Mustard With Bell Chilly', 22000, 0, 0, 'Lá cải xanh đồng hành cùng những miếng lát ớt cắt nhỏ vô cùng hấp dẫn.', '', 'cxxoc.jpg', '', '', '', 6, 2, 1),
(7, 1, 'Cơm Hải Sản', 'Fried Rice With Sea Foods', 32000, 0, 0, 'Cơm hải sản thơm ngon đặc biệt.', '', 'cchs.jpg', '', '', '', 7, 0, 1),
(8, 1, 'Lẩu Dê Nướng Vú Bò', 'Goat Meat Hotspot', 120000, 0, 0, 'Thịt dê xé hòa quyện cùng mùi vị của bò tạo nên món lẩu LẠ, ĐỘC và NGON.', '', 'ldnvb.jpg', '', '', '', 8, 0, 1),
(9, 1, 'Bánh Kem Táo', 'Apple Pie', 250000, 0, 0, 'Kem và táo tạo nên một chiếc bánh vô cùng lạ miệng và háp dẫn. Chắc chắn sẽ thu hút bạn khi bạn nếm miếng bánh đầu tiên.', '', 'bkt.jpg', '', '', '', 9, 0, 1),
(10, 1, 'Lẩu Thái', 'Tom Yum', 150000, 0, 0, 'Quá quen thuộc với người Việt. Đó chính là lẩu Thái.', '', 'lt.jpg', '', '', '', 10, 0, 1),
(11, 2, 'Cocacola', 'Coke', 10000, 0, 0, 'Nước giải khát Cocacola.', '', 'cccl.jpg', '', '', '', 1, 19, 1),
(12, 2, 'Pepsi', 'Pepsi', 10000, 0, 0, 'Nước giải khát Pepsi.', '', 'ps.jpg', '', '', '', 2, 9, 1),
(13, 2, '7up', '7up', 10000, 0, 0, 'Nước giải khát 7up.', '', '7up.jpg', '', '', '', 3, 2, 1),
(14, 2, 'Mirinda Cam', 'Orange Mirinda ', 10000, 0, 0, 'Nước giải khát Mirinda.', '', 'mrdc.jpg', '', '', '', 4, 0, 1),
(15, 2, 'Mirinda', 'Mirinda', 10000, 0, 0, 'Nước giải khát Midinra.', '', 'mrd.jpg', '', '', '', 5, 0, 1),
(16, 2, 'Đá Me', 'Tamarind Juice', 0, 0, 0, 'Nước giải khát chua ngọt.', '', 'dm.jpg', '', '', '', 6, 0, 1),
(17, 2, 'Trà Tắc', 'Cumquat Tea', 15000, 0, 0, 'Nước giải khát Trà hòa quyện cùng Tắt.', '', 'tt.jpg', '', '', '', 7, 0, 1),
(18, 2, 'Sinh Tố Dâu', 'Strawberry Juice', 20000, 0, 0, 'Nước giải khát.', '', 'std.jpg', '', '', '', 8, 0, 1),
(19, 2, 'Sinh Tố Mãng Cầu', 'Soursop Juice', 22000, 0, 0, 'Nước giải khát.', '', 'stmc.jpg', '', '', '', 9, 0, 1),
(20, 2, 'Sinh Tố Cà Rốt', 'Carrot Juice', 18000, 0, 0, 'Nước giải khát.', '', 'stcr.jpg', '', '', '', 10, 0, 1),
(21, 3, 'Nho Mỹ Ướp Lạnh', 'Iced Grape', 30000, 0, 0, 'Nho xanh rượm ngọt như mía lụi.', '', 'nmul.jpg', '', '', '', 1, 0, 1),
(22, 3, 'Bánh Plan Ánh Hồng', '', 10000, 0, 0, 'Bánh Plan gồm cà phê đen và được tô thêm màu Hồng..', '', 'blah.jpg', '', '', '', 2, 0, 1),
(23, 3, 'Bò Bía', 'Popiah', 30000, 0, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 'bb.jpg', '', '', '', 3, 0, 1),
(24, 3, 'Bánh Bèo', 'Beo Cake', 25000, 0, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 'bbeo.jpg', '', '', '', 4, 0, 1),
(25, 3, 'Bánh Khọt', 'Khot Cake', 35000, 0, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 'bk.jpg', '', '', '', 5, 0, 1),
(26, 3, 'Gỏi Cuốn', '', 30000, 0, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 'gc.jpg', '', '', '', 6, 0, 1),
(27, 3, 'Bánh Bột Lọc', '', 30000, 0, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 'bbl.jpg', '', '', '', 7, 0, 1),
(28, 3, 'Cá Viên Chiên', '', 10000, 0, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 'cvc.jpg', '', '', '', 8, 0, 1),
(29, 3, 'Bắp Rang Bơ', '', 15000, 0, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 'brb.jpg', '', '', '', 9, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `of_manage`
--

CREATE TABLE `of_manage` (
  `id` int(11) NOT NULL,
  `account` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `cate` tinyint(4) NOT NULL COMMENT '1: Bếp, 2: Thanh toán, 3: Nhân Viên, 4: Bếp Pha Chế',
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `of_manage`
--

INSERT INTO `of_manage` (`id`, `account`, `password`, `name`, `cate`, `active`) VALUES
(1, 'bep', 'ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413', 'Quản Lý Danh Sách Món Ăn', 1, 1),
(2, 'thanhtoan', 'ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413', 'Quản Lý Thanh Toán', 2, 1),
(3, 'nhanvien', 'ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413', 'Quản Lý Nhân Viên', 3, 1),
(4, 'bepphache', 'ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413', 'Quản Lý Bếp Pha Chế', 4, 1),
(7, 'duy', '8999d4b67760096a57292312a1c40fb89ed11ce6c115f86afa0824fef5bf0789be30cd7d1a392b342e643f36a71cb258b379927cc96dd1b6f04ac6cde503c9c3', 'DuyTran', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `of_note_order`
--

CREATE TABLE `of_note_order` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `note` text NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `of_order`
--

CREATE TABLE `of_order` (
  `id` int(11) NOT NULL,
  `num_table` int(11) NOT NULL,
  `active` int(11) NOT NULL COMMENT '0: đang chờ, 2: bếp đang xử lý, 1: xong'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `of_order_detail`
--

CREATE TABLE `of_order_detail` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `food_id` int(25) NOT NULL,
  `price` double NOT NULL,
  `qty` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL COMMENT '0: đang chờ, 2: bếp đang xử lý, 1: xong',
  `country` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `of_rate`
--

CREATE TABLE `of_rate` (
  `id` int(11) NOT NULL,
  `desc` text NOT NULL,
  `star` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `of_slider`
--

CREATE TABLE `of_slider` (
  `id` int(11) NOT NULL,
  `vi_name` varchar(500) NOT NULL,
  `en_name` varchar(500) NOT NULL,
  `vi_content` text NOT NULL,
  `en_content` text NOT NULL,
  `img_url` varchar(255) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `of_slider`
--

INSERT INTO `of_slider` (`id`, `vi_name`, `en_name`, `vi_content`, `en_content`, `img_url`, `create_at`) VALUES
(1, 'Giới Thiệu 1', 'Advertise 1', 'Được thành lập năm 2007, do Cha Phó lúc bấy giờ là cha Giuse Vũ Văn Quyên, một người rất đa tài với giọng nói vô cùng nhẹ nhàng và lôi cuốn.  Ca đoàn vinh dự được Cha chọn tên Emmanuel và lấy ngày 25/12, ngày Chúa giáng sinh, làm ngày bổn mạng Ca Đoàn, đặt tên là \"Ca Đoàn Emmanuel\" hay còn có tên gọi khác là \"Ca Đoàn Giới Trẻ\", phụ trách lễ 19h00 Chúa nhật hàng tuần.  Trải qua bao thăng trầm của thời gian, cùng với sự vẫy vùng của tuổi trẻ, số lượng thành viên ca đoàn luôn biến động và thay đổi như những dòng thủy lưu. Những cánh chim này bay đi và những cánh chim khác lại chọn CD Emmanuel làm bến đỗ. Những hoài bão, những khát khao của tuổi trẻ luôn là nguồn năng lượng dồi dào cho những cánh chim không mỏi. Họ bay khắp nơi trong bầu trời của Chúa và đáp xuống những mảnh đất họ tìm thấy hạnh phúc và bình yên. Nhưng chính sự thay đổi liên tục này, về một góc nhìn khác, cũng là một yếu tố tạo nên sự đa dạng và mới mẽ cho những sinh hoạt của Ca Đoàn.  Số lượng thành viên hiện tại của Ca Đoàn (tháng 7/2018) khoảng 35 thành viên với nhiệt huyết và tinh thần phụng vụ luôn tràn đầy trong mỗi trái tim, với độ tuổi từ 16 cho đến 50, và tất cả đều là Anh Em.', 'Anyone who reads Old and Middle English literary texts will be familiar with the mid-brown volumes of the EETS, with the symbol of Alfred\'s jewel embossed on the front cover. Most of the works attributed to King Alfred or to Aelfric, along with some of th', 'slide1.jpg', '2019-01-18 05:02:14'),
(2, 'Giới Thiệu 2', 'Advertise 2', 'Được thành lập năm 2007, do Cha Phó lúc bấy giờ là cha Giuse Vũ Văn Quyên, một người rất đa tài với giọng nói vô cùng nhẹ nhàng và lôi cuốn.  Ca đoàn vinh dự được Cha chọn tên Emmanuel và lấy ngày 25/12, ngày Chúa giáng sinh, làm ngày bổn mạng Ca Đoàn, đặt tên là \"Ca Đoàn Emmanuel\" hay còn có tên gọi khác là \"Ca Đoàn Giới Trẻ\", phụ trách lễ 19h00 Chúa nhật hàng tuần.  Trải qua bao thăng trầm của thời gian, cùng với sự vẫy vùng của tuổi trẻ, số lượng thành viên ca đoàn luôn biến động và thay đổi như những dòng thủy lưu. Những cánh chim này bay đi và những cánh chim khác lại chọn CD Emmanuel làm bến đỗ. Những hoài bão, những khát khao của tuổi trẻ luôn là nguồn năng lượng dồi dào cho những cánh chim không mỏi. Họ bay khắp nơi trong bầu trời của Chúa và đáp xuống những mảnh đất họ tìm thấy hạnh phúc và bình yên. Nhưng chính sự thay đổi liên tục này, về một góc nhìn khác, cũng là một yếu tố tạo nên sự đa dạng và mới mẽ cho những sinh hoạt của Ca Đoàn.  Số lượng thành viên hiện tại của Ca Đoàn (tháng 7/2018) khoảng 35 thành viên với nhiệt huyết và tinh thần phụng vụ luôn tràn đầy trong mỗi trái tim, với độ tuổi từ 16 cho đến 50, và tất cả đều là Anh Em.', 'Anyone who reads Old and Middle English literary t...', 'slide2.jpg', '2019-01-18 05:02:17'),
(3, 'Giới Thiệu 3', 'Advertise 3', 'Được thành lập năm 2007, do Cha Phó lúc bấy giờ là cha Giuse Vũ Văn Quyên, một người rất đa tài với giọng nói vô cùng nhẹ nhàng và lôi cuốn.  Ca đoàn vinh dự được Cha chọn tên Emmanuel và lấy ngày 25/12, ngày Chúa giáng sinh, làm ngày bổn mạng Ca Đoàn, đặt tên là \"Ca Đoàn Emmanuel\" hay còn có tên gọi khác là \"Ca Đoàn Giới Trẻ\", phụ trách lễ 19h00 Chúa nhật hàng tuần.  Trải qua bao thăng trầm của thời gian, cùng với sự vẫy vùng của tuổi trẻ, số lượng thành viên ca đoàn luôn biến động và thay đổi như những dòng thủy lưu. Những cánh chim này bay đi và những cánh chim khác lại chọn CD Emmanuel làm bến đỗ. Những hoài bão, những khát khao của tuổi trẻ luôn là nguồn năng lượng dồi dào cho những cánh chim không mỏi. Họ bay khắp nơi trong bầu trời của Chúa và đáp xuống những mảnh đất họ tìm thấy hạnh phúc và bình yên. Nhưng chính sự thay đổi liên tục này, về một góc nhìn khác, cũng là một yếu tố tạo nên sự đa dạng và mới mẽ cho những sinh hoạt của Ca Đoàn.  Số lượng thành viên hiện tại của Ca Đoàn (tháng 7/2018) khoảng 35 thành viên với nhiệt huyết và tinh thần phụng vụ luôn tràn đầy trong mỗi trái tim, với độ tuổi từ 16 cho đến 50, và tất cả đều là Anh Em.', 'Anyone who reads Old and Middle English literary t...', 'slide3.jpg', '2019-01-18 05:02:20');

-- --------------------------------------------------------

--
-- Table structure for table `of_solve_pay`
--

CREATE TABLE `of_solve_pay` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `num_table` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `of_user`
--

CREATE TABLE `of_user` (
  `id` int(11) NOT NULL,
  `name` int(255) NOT NULL,
  `active` tinyint(4) NOT NULL COMMENT '0: khóa, 1:mở, 2: đã đăng nhập '
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `of_user`
--

INSERT INTO `of_user` (`id`, `name`, `active`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 1),
(6, 6, 1),
(7, 7, 1),
(8, 8, 1),
(9, 9, 1),
(10, 10, 1),
(11, 11, 1),
(12, 12, 1),
(13, 13, 1),
(14, 14, 1),
(15, 15, 1),
(16, 16, 1),
(17, 17, 1),
(18, 18, 1),
(19, 19, 1),
(20, 20, 1),
(21, 21, 1),
(22, 22, 1),
(23, 23, 1),
(24, 24, 1),
(25, 25, 1),
(26, 26, 1),
(27, 27, 1),
(28, 28, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `of_admin`
--
ALTER TABLE `of_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_bill`
--
ALTER TABLE `of_bill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_category`
--
ALTER TABLE `of_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_department`
--
ALTER TABLE `of_department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_discount`
--
ALTER TABLE `of_discount`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_food`
--
ALTER TABLE `of_food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_manage`
--
ALTER TABLE `of_manage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_note_order`
--
ALTER TABLE `of_note_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_order`
--
ALTER TABLE `of_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_order_detail`
--
ALTER TABLE `of_order_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_rate`
--
ALTER TABLE `of_rate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_slider`
--
ALTER TABLE `of_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_solve_pay`
--
ALTER TABLE `of_solve_pay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_user`
--
ALTER TABLE `of_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `of_admin`
--
ALTER TABLE `of_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `of_bill`
--
ALTER TABLE `of_bill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `of_category`
--
ALTER TABLE `of_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `of_department`
--
ALTER TABLE `of_department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `of_discount`
--
ALTER TABLE `of_discount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `of_food`
--
ALTER TABLE `of_food`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `of_manage`
--
ALTER TABLE `of_manage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `of_note_order`
--
ALTER TABLE `of_note_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `of_order`
--
ALTER TABLE `of_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `of_order_detail`
--
ALTER TABLE `of_order_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `of_rate`
--
ALTER TABLE `of_rate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `of_slider`
--
ALTER TABLE `of_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `of_solve_pay`
--
ALTER TABLE `of_solve_pay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `of_user`
--
ALTER TABLE `of_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
