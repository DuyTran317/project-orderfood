-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2018 at 09:54 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orderfood`
--
CREATE DATABASE IF NOT EXISTS `orderfood` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `orderfood`;

-- --------------------------------------------------------

--
-- Table structure for table `of_admin`
--

CREATE TABLE `of_admin` (
  `id` int(11) NOT NULL,
  `account` varchar(255) NOT NULL,
  `password` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `cate` tinyint(4) NOT NULL COMMENT '1: Bếp, 2: Thanh toán',
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `of_bill`
--

CREATE TABLE `of_bill` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `num_table` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `active` int(11) NOT NULL COMMENT '0: chưa, 1: xong'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `of_drink`
--

CREATE TABLE `of_drink` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `discount` int(11) NOT NULL,
  `desc` text NOT NULL,
  `img_url` varchar(255) NOT NULL,
  `order` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `of_drink`
--

INSERT INTO `of_drink` (`id`, `name`, `price`, `discount`, `desc`, `img_url`, `order`, `active`) VALUES
(1, 'Cocacola', 10000, 0, 'Nước giải khát Cocacola.', '', 1, 1),
(2, 'Pepsi', 10000, 0, 'Nước giải khát Pepsi.', '', 2, 1),
(3, '7up', 10000, 0, 'Nước giải khát 7up.', '', 3, 1),
(4, 'Mirinda Cam', 10000, 0, 'Nước giải khát Mirinda.', '', 4, 1),
(5, 'Midinra', 10000, 0, 'Nước giải khát Mirinda.', '', 5, 1),
(6, 'Đá Me', 12000, 0, 'Nước giải khát chua ngọt.', '', 6, 1),
(7, 'Trà Tắc', 15000, 0, 'Nước giải khát Trà hòa quyện cùng Tắt.', '', 7, 1),
(8, 'Sinh Tố Dâu', 20000, 0, 'Nước giải khát.', '', 8, 1),
(9, 'Sinh Tố Mãng Cầu', 22000, 0, 'Nước giải khát.', '', 9, 1),
(10, 'Sinh Tố Cà Rốt', 18000, 0, 'Nước giải khát.', '', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `of_food`
--

CREATE TABLE `of_food` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `discount` int(11) NOT NULL,
  `desc` text NOT NULL,
  `img_url` varchar(255) NOT NULL,
  `order` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `of_food`
--

INSERT INTO `of_food` (`id`, `name`, `price`, `discount`, `desc`, `img_url`, `order`, `active`) VALUES
(1, 'Ốc Sào Rang Me', 120000, 0, 'Ốc bưu kết hợp với trai me tạo nên món Ốc sào rang me siêu ngon và hấp dẫn.', '', 1, 1),
(2, 'Cơm Chiên Dương Châu', 30000, 0, 'Cơm chiên màu vàng và có cà rốt nên được gọi là cơm chiên Dương Châu.', '', 2, 1),
(3, 'Cơm Cá Lóc Canh Chua', 35000, 0, 'Cơm gồm cá lóc và canh chua nên được gọi là \"Cá lóc canh chua\".', '', 3, 1),
(4, 'Ốc Móng Tay Xào Rau Muống', 55000, 5, 'Ốc sạch và rau sạch tạo nên 1 món ăn sạch và đảm bảo sẽ ngon miệng.', '', 4, 1),
(5, 'Nấm Mèo Rang Ớt', 45000, 0, 'Nấm mèo được pha trộn với ớt tạo nên 1 món ăn vừa ngon vừa cay. Phù hợp với lứa tuổi trung niên và người có thể ăn cay.', '', 5, 1),
(6, 'Cải Xanh Xào Ớt Chuông', 22000, 0, 'Lá cải xanh đồng hành cùng những miếng lát ớt cắt nhỏ vô cùng hấp dẫn.', '', 6, 1),
(7, 'Cơm Hải Sản', 32000, 0, 'Cơm hải sản thơm ngon đặc biệt.', '', 7, 1),
(8, 'Lẩu Dê Nướng Vú Bò', 120000, 10, 'Thịt dê xé hòa quyện cùng mùi vị của bò tạo nên món lẩu LẠ, ĐỘC và NGON.', '', 8, 1),
(9, 'Bánh Kem Táo', 250000, 10, 'Kem và táo tạo nên một chiếc bánh vô cùng lạ miệng và háp dẫn. Chắc chắn sẽ thu hút bạn khi bạn nếm miếng bánh đầu tiên.', '', 9, 1),
(10, 'Lẩu Thái', 150000, 0, 'Quá quen thuộc với người Việt. Đó chính là lẩu Thái.', '', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `of_order`
--

CREATE TABLE `of_order` (
  `id` int(11) NOT NULL,
  `num_table` int(11) NOT NULL,
  `active` int(11) NOT NULL COMMENT '0: đang chờ, 1: xong'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `of_order_detail`
--

CREATE TABLE `of_order_detail` (
  `order_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `qty` int(11) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `of_others`
--

CREATE TABLE `of_others` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `discount` int(11) NOT NULL,
  `desc` text NOT NULL,
  `img_url` varchar(255) NOT NULL,
  `order` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `of_others`
--

INSERT INTO `of_others` (`id`, `name`, `price`, `discount`, `desc`, `img_url`, `order`, `active`) VALUES
(1, 'Nho Mỹ Ướp Lạnh', 50000, 0, 'Nho xanh rượm ngọt như mía lụi.', '', 1, 1),
(2, 'Bánh Plan Ánh Hồng', 10000, 0, 'Bánh Plan gồm cà phê đen và được tô thêm màu Hồng.', '', 2, 1),
(3, 'Bò Bía', 30000, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 3, 1),
(4, 'Bánh Bèo', 25000, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 4, 1),
(5, 'Bò Khọt', 20000, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 5, 1),
(6, 'Gỏi Cuốn', 32000, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 6, 1),
(7, 'Bánh Bột Lọc', 30000, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 7, 1),
(8, 'Cá Viên Chiên', 10000, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 8, 1),
(9, 'Bắp Rang Bơ', 15000, 0, 'Ăn chơi xã xì trét và thư giãn.', '', 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `of_rate`
--

CREATE TABLE `of_rate` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  `star` int(11) NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `of_rate`
--

INSERT INTO `of_rate` (`id`, `customer_name`, `desc`, `star`, `active`) VALUES
(1, 'Trần Đình Duy', 'Quán có rất nhiều món ngon. Chịu ! Okay !', 5, 1),
(2, 'Đỗ Đăng Khoa', 'Quán mát mẻ sảng khoái và dễ chịu.', 4, 1),
(3, 'Khang Nam Kiệt', 'Tuy có nhiều món ngon nhưng vẫn còn vài món chưa ngon!', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `of_user`
--

CREATE TABLE `of_user` (
  `id` int(11) NOT NULL,
  `account` varchar(255) NOT NULL,
  `password` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `of_admin`
--
ALTER TABLE `of_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_bill`
--
ALTER TABLE `of_bill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_drink`
--
ALTER TABLE `of_drink`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_food`
--
ALTER TABLE `of_food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_order`
--
ALTER TABLE `of_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_order_detail`
--
ALTER TABLE `of_order_detail`
  ADD PRIMARY KEY (`order_id`,`name`);

--
-- Indexes for table `of_others`
--
ALTER TABLE `of_others`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_rate`
--
ALTER TABLE `of_rate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `of_user`
--
ALTER TABLE `of_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `of_admin`
--
ALTER TABLE `of_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `of_bill`
--
ALTER TABLE `of_bill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `of_drink`
--
ALTER TABLE `of_drink`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `of_food`
--
ALTER TABLE `of_food`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `of_order`
--
ALTER TABLE `of_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `of_order_detail`
--
ALTER TABLE `of_order_detail`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `of_others`
--
ALTER TABLE `of_others`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `of_rate`
--
ALTER TABLE `of_rate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `of_user`
--
ALTER TABLE `of_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
